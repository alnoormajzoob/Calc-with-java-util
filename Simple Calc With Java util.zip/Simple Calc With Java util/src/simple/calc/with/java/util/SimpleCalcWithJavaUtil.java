/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simple.calc.with.java.util;

import java.util.Scanner;
/**
 *
 * @author alnoor
 */
public class SimpleCalcWithJavaUtil {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner obInput , numInput;
        System.out.println("Select -> 1:sum , 2:sub , 3:div , 4:mult");
        
        obInput = new Scanner(System.in);
        numInput = new Scanner(System.in);
        
        try{
        int obSelect = obInput.nextInt();
        System.out.print("Enter The Frist No : ");
        double num1 = numInput.nextDouble();
        
        System.out.print("Enter The Second No : ");
        double num2 = numInput.nextDouble();
        
        switch(obSelect)
        {
            case 1:
                System.out.println("The Result is :" + Math.sum(num1, num2));
                break;
            case 2:
                System.out.println("The Result is :" + Math.sub(num1, num2));
                break;
            case 3:
                System.out.println("The Result is :" + Math.div(num1, num2));
                break;
            case 4:
                System.out.println("The Result is :" + Math.mult(num1, num2));
                break;
            default:
                 System.out.println("Please Try again with dif ob ");
                break;
        }
            
   }//try block
    catch(Exception e)
    {
        System.out.println("InputMisMatchException");
    }
    finally
    {
        obInput.close();
        numInput.close();
    }//finally block
}//main method block
}//class block

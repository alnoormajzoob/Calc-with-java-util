/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package simple.calc.with.java.util;

/**
 *
 * @author alnoor
 */
public class Math {
    
     public static double sum(double x , double y)
     {
         return x + y;
     }
     
     public static double sub(double x , double y)
     {
         return x - y;
     }
     
     public static double div(double x , double y)
     {
         if(y==0)
             return 0;
         else
             return x / y ;
     }
     
     public static double mult(double x , double y)
     {
         return x * y;
     }
    
     public static void printResult(){
         
     }
}
